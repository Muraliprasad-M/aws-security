# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_aws_owners" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-aws-owners"
  description = "Provides full access to target accounts except S3."

  group_name = "AWS Roles - Owners"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/AdministratorAccess",
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "624337930029",
    "579039993305",
    "926630425927",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "N/A"
    Environment = "prod"
  }
}

output "owners_permission_set_arn" {
  description = "ARN of the stw-readonly-cyber permission set."
  value       = module.stw_aws_owners.permission_set_arn
}

output "owners_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_aws_owners.assigned_account_ids
}
