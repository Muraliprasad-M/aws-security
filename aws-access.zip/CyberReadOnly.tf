# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_readonly_cyber" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-cyber"
  description = "SRQ0002005991. Allows Cyber Read Only to All Accounts but denies access to S3 outside of cyber accounts. Updated for test now."

  group_name = "AWS Roles - Security ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/ReadOnlyAccess",
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3OutsideCyberAccounts"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "aws:PrincipalAccount" = [
              "381709151858",
              "074122282940",
            ]
          }
        }
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "058293109894",
    "579039993305",
    "074122282940",
    "381709151858",
    "732822664028",
    "624337930029",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "cyber"
    Environment = "prod"
  }
}

output "cyber_permission_set_arn" {
  description = "ARN of the stw-readonly-cyber permission set."
  value       = module.stw_readonly_cyber.permission_set_arn
}

output "cyber_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_cyber.assigned_account_ids
}
