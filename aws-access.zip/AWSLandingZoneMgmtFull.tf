# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_landingzone_mgmt_full" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-landingzone-mgmt-full"
  description = "AWS Landing Zone Management permission set to allow landgin zone upgrades."

  group_name = "AWS Roles - LandingZone Management Admin"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/AdministratorAccess",
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "624337930029",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "operations"
    Environment = "prod"
    SRQ         = "SRQ0002005991"
  }
}

output "landingzone-mgmt-full_permission_set_arn" {
  description = "ARN of the stw-landingzone-mgmt-full permission set."
  value       = module.stw_landingzone_mgmt_full.permission_set_arn
}

output "landingzone-mgmt-full_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_landingzone_mgmt_full.assigned_account_ids
}
