# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_readonly_operations_ou" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-operations-ou"
  description = "SRQ0002005991. Allows Operations Read Only to view the OU structure in AWS Organisations."

  group_name = "AWS Roles - Operations ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
      },
      {
        Sid    = "OUMgmtRead"
        Effect = "Allow"
        Action = [
          "organizations:DescribeOrganization",
          "organizations:ListRoots",
          "organizations:ListOrganizationalUnitsForParent",
          "organizations:ListAccountsForParent",
          "organizations:ListAccounts",
          "organizations:DescribeOrganizationalUnit",
          "organizations:DescribeAccount",
          "organizations:ListChildren",
          "organizations:ListParents",
          "organizations:ListTagsForResource"
        ]
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "624337930029",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "operations"
    Environment = "prod"
  }
}

output "operations_ou_permission_set_arn" {
  description = "ARN of the stw-readonly-operations-ou permission set."
  value       = module.stw_readonly_operations_ou.permission_set_arn
}

output "operations_ou_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_operations_ou.assigned_account_ids
}
