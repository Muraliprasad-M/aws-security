# Grants the finops team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_readonly_finops" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-finops"
  description = "Allows FinOps Team Read Only Access to FinOps Account."

  group_name = "AWS Roles - FinOps ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
  ]

  # Deny S3 access when operating in any account that is not a designated finops account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3OutsidefinopsAccounts"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "aws:PrincipalAccount" = [
              "953734004222",
            ]
          }
        }
      },
      {
        # Allows finops staff to assume a role in the mgmt account to use org wide cost explorer
        # This used to be delegated but is no longer supported and so has to be done from within
        # the management account. Role being assumed has full rights within cost explorer only.
        # Update the below role in the mgmt account if it requires fine tuning.
        Sid      = "EnableCostExplorerAccessviaMGMTAcc"
        Effect   = "Allow"
        Action   = "sts:AssumeRole"
        Resource = "arn:aws:iam::624337930029:role/st-finops-prod-cost-explorer-access"
      },
      {
        # CUR (Cost and Usage Reports) are replicated from MGMT account to the bucket in the finops account
        # This allows the finops team view the bucket in the list of buckets but no others.
        Sid      = "EnableS3AccesstoCURExportsListBucket"
        Effect   = "Allow"
        Action   = "s3:ListBucket"
        Resource = "arn:aws:s3:::st-controlplane-finops-cur-data-d9ak23"
      },
      {
        # Allows the finops team to list all buckets. Avoids having to use direct URLs to access
        # the bucket
        Sid      = "EnableS3ListAllBuckets"
        Effect   = "Allow"
        Action   = "s3:ListAllMyBuckets"
        Resource = "*"
      },
      {
        # CUR (Cost and Usage Reports) are replicated from MGMT account to the bucket in the finops account
        # This allows the finops team to view the contents of the bucket
        Sid      = "EnableS3AccesstoCURExportGetObject"
        Effect   = "Allow"
        Action   = "s3:GetObject"
        Resource = "arn:aws:s3:::st-controlplane-finops-cur-data-d9ak23/*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "953734004222"
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "finops"
    Environment = "prod"
  }
}

output "finops_permission_set_arn" {
  description = "ARN of the stw-readonly-finops permission set."
  value       = module.stw_readonly_finops.permission_set_arn
}

output "finops_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_finops.assigned_account_ids
}
