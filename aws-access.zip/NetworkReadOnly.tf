# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_readonly_network" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-network"
  description = "SRQ0002005991. Allows read only access to the network account"

  group_name = "AWS Roles - Network ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowNetworkModifications"
        Effect = "Allow"
        Action = [
          "ec2:DescribeAccountAttributes",
          "ec2:DescribeAddresses",
          "ec2:DescribeAvailabilityZones",
          "ec2:DescribeCarrierGateways",
          "ec2:DescribeClassicLinkInstances",
          "ec2:DescribeCustomerGateways",
          "ec2:DescribeDhcpOptions",
          "ec2:DescribeEgressOnlyInternetGateways",
          "ec2:DescribeFlowLogs",
          "ec2:DescribeInternetGateways",
          "ec2:DescribeLocalGatewayRouteTables",
          "ec2:DescribeLocalGatewayRouteTableVpcAssociations",
          "ec2:DescribeNatGateways",
          "ec2:DescribeNetworkAcls",
          "ec2:DescribeNetworkInterfaceAttribute",
          "ec2:DescribeNetworkInterfacePermissions",
          "ec2:DescribeNetworkInterfaces",
          "ec2:DescribePrefixLists",
          "ec2:DescribeRouteTables",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeSecurityGroupRules",
          "ec2:DescribeSecurityGroupReferences",
          "ec2:DescribeStaleSecurityGroups",
          "ec2:DescribeSubnets",
          "ec2:DescribeTags",
          "ec2:DescribeVpcAttribute",
          "ec2:DescribeVpcClassicLink",
          "ec2:DescribeVpcClassicLinkDnsSupport",
          "ec2:DescribeVpcEndpoints",
          "ec2:DescribeVpcEndpointConnections",
          "ec2:DescribeVpcEndpointServiceConfigurations",
          "ec2:DescribeVpcEndpointServicePermissions",
          "ec2:DescribeVpcEndpointServices",
          "ec2:DescribeVpcPeeringConnections",
          "ec2:DescribeVpcs",
          "ec2:DescribeVpnConnections",
          "ec2:DescribeVpnGateways",
          "ec2:GetSecurityGroupsForVpc",    
          "network-firewall:Describe*",
          "network-firewall:List*"
        ]
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "732822664028",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "cyber"
    Environment = "prod"
  }
}

output "network_permission_set_arn" {
  description = "ARN of the stw-readonly-cyber permission set."
  value       = module.stw_readonly_network.permission_set_arn
}

output "network_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_network.assigned_account_ids
}