# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
module "stw_readonly_operations_aft" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-operations-aft"
  description = "SRQ0002005991. Allows Operations Read Only to the AFT account."

  group_name = "AWS Roles - Operations ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/ReadOnlyAccess",
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = [
    "579039993305",
  ]

  session_duration = "PT4H"

  tags = {
    Team        = "operations"
    Environment = "prod"
  }
}

output "operations_aft_permission_set_arn" {
  description = "ARN of the stw-readonly-operations-aft permission set."
  value       = module.stw_readonly_operations_aft.permission_set_arn
}

output "operations_aft_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_operations_aft.assigned_account_ids
}
