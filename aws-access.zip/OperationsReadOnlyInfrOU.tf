# Grants the Cyber team read-only access across all accounts, with S3 access
# restricted to their designated accounts only.
data "aws_organizations_organizational_unit_descendant_accounts" "target_ou" {
  parent_id = "ou-q8uh-ernh5v92"
}

#Targeting every account under the infrastructure OU
module "stw_readonly_operations_infrastructure_ou" {
  source = "git::https://dev.azure.com/severntrent/aws-security/_git/aws-security-ssopermissionset-module?ref=main"

  name        = "stw-readonly-operations-infra-ou"
  description = "SRQ0002005991. Allows Operations Read Only to all accounts under infrastructure OU."

  group_name = "AWS Roles - Operations ReadOnly"

  # Broad read-only access across all AWS services.
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/ReadOnlyAccess",
  ]

  # Deny S3 access when operating in any account that is not a designated cyber account.
  inline_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "DenyS3"
        Effect   = "Deny"
        Action   = "s3:*"
        Resource = "*"
      }
    ]
  })

  # List all accounts this permission set should be assigned to.
  account_ids = data.aws_organizations_organizational_unit_descendant_accounts.target_ou.accounts[*].id

  session_duration = "PT4H"

  tags = {
    Team        = "operations"
    Environment = "prod"
  }
}

output "operations_infrastructure_ou_permission_set_arn" {
  description = "ARN of the stw-readonly-operations-infrastructure-ou permission set."
  value       = module.stw_readonly_operations_infrastructure_ou.permission_set_arn
}

output "operations_infrastructure_ou_assigned_account_ids" {
  description = "Accounts the permission set was assigned to."
  value       = module.stw_readonly_operations_infrastructure_ou.assigned_account_ids
}
