# Custom Policies

This repository contains custom Service Control Policies that enforce organisational controls across Severn Trent AWS Accounts that are not available as part of AWS built-in controls.


