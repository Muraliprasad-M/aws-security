# Specify TFLint plugin
plugin "aws" {
    version = "0.45.0"
    enabled = true
    source = "github.com/terraform-linters/tflint-ruleset-aws"
}
