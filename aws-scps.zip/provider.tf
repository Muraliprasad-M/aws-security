terraform {
  required_version = ">= 1.14.5, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">=6.0.0"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region = "eu-west-2"
}
