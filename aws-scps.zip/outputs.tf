output "scp_json" {
  value = data.aws_iam_policy_document.deny_egress.json
}
