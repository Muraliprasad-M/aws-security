data "aws_iam_policy_document" "deny_egress" {
  statement {
    sid       = "DenyIGW"
    effect    = "Deny"
    actions   = ["ec2:CreateInternetGateway", "ec2:AttachInternetGateway"]
    resources = ["*"]
  }
  statement {
    sid       = "DenyNatGW"
    effect    = "Deny"
    actions   = ["ec2:CreateNatGateway"]
    resources = ["*"]
  }
  statement {
    sid       = "DenyDefaultVPC"
    effect    = "Deny"
    actions   = ["ec2:CreateDefaultVpc"]
    resources = ["*"]
  }
  statement {
    sid       = "DenyElasticIP"
    effect    = "Deny"
    actions   = ["ec2:AllocateAddress"]
    resources = ["*"]
  }
}

