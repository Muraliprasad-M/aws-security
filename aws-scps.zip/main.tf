resource "aws_organizations_policy" "deny_egress" {
  name        = "DenyEgress"
  description = "Prevent creation of IGW, NatGW, Default VPC and EIPs"
  type        = "SERVICE_CONTROL_POLICY"
  content     = data.aws_iam_policy_document.deny_egress.json
}

locals {
  target_ou_ids = [
    "ou-q8uh-duj1pqtl", #Sandbox OU
    "ou-q8uh-ernh5v92", #Infrastructure OU
    "ou-q8uh-t13m6ky6", #Control-Plane OU
    "ou-q8uh-z7dzrt87"  #Security OU
  ]
}

resource "aws_organizations_policy_attachment" "deny_egress_attachment" {
  for_each = toset(local.target_ou_ids)

  policy_id = aws_organizations_policy.deny_egress.id
  target_id = each.key
}
