# Control Policies

This directory manages what conntrols are applied where. This is maintained in the `locals.tf` file.

## Prerequisites

Before creating a permission set, confirm the following:

- The ARN of the control you wish to enable/disable.
- You know the OU where you want the control to apply OR if it's a control that must apply across all OU's
- If it's a new top level OU (one beneath the management OU) then the name of it to be added to the list of applicable OU's.

---

## Applying a control

### 1. Identify the ARN of the control.

Make a note of the ARN for any control(s) you want to apply and where you want to apply them. You can find the ARN here on any control:

![ALT text](assets/policyarn.png)

Or via CLI:
```
# Searches for any control with S3 in the name
aws controltower list-controls --query "controls[?contains(name, 'S3')]" 
```

### 2. Apply control across all OU's

Add the ARN(s) to the existing `baseline_controls` local in the `locals.tf` file. For example:
```
baseline_controls = [
    "arn:aws:controlcatalog:::control/m7a5gbdf08wg2o0en010mkng",
]
```
### 3. Apply control to specific OU's

Add the ARN(s) to the existing `security_ou_controls`, `sandbox_ou_controls`, `workloads_ou_controls`, `controlplane_ou_controls`, `core_ou_controls` as appropriate. For example below we apply one control to the security and sandbox OU's:
```
 security_ou_controls = [
    # additional security OU controls
    "arn:aws:controlcatalog:::control/m7a5gbdf08wg2o0en010mkng",
  ]

  sandbox_ou_controls = [
    # additional sandbox OU controls
    "arn:aws:controlcatalog:::control/m7a5gbdf08wg2o0en010mkng",
  ]
```

## Add new Top level OU's

If a new top level OU (one below management) is created then they will need to be added to the `locals.tf` file.

The below example adds a new `test` OU arn:
```
ou_arns = {
    "ou-security"      = "arn:aws:organizations::624337930029:ou/o-tzqtah1jet/ou-q8uh-z7dzrt87"
    "ou-workloads"     = "arn:aws:organizations::624337930029:ou/o-tzqtah1jet/ou-q8uh-ernh5v92"
    "ou-sandbox"       = "arn:aws:organizations::624337930029:ou/o-tzqtah1jet/ou-q8uh-duj1pqtl"
    "ou-control-plane" = "arn:aws:organizations::624337930029:ou/o-tzqtah1jet/ou-q8uh-t13m6ky6"
    "core"             = "arn:aws:organizations::624337930029:ou/o-tzqtah1jet/ou-q8uh-70yiw7p0"
    "test"             = "ARN OF TEST OU"
  }
```
In the same document if you want to apply policies to just that OU you need to add a new `local` for it like below:
```
  core_ou_controls = [
    # additional core OU controls
  ]

  test_ou_controls = [
    # addtional test OU controls
  ]
```
Lastly add it to the `ou_controls` local.
```
  ou_controls = {
    for ou in local.ous :
    ou => distinct(concat(
      local.baseline_controls,
      lookup({
        "ou-security"      = local.security_ou_controls
        "ou-sandbox"       = local.sandbox_ou_controls
        "ou-workloads"     = local.workloads_ou_controls
        "ou-control-plane" = local.controlplane_ou_controls
        "ou-core"          = local.core_ou_controls
        "ou-test"          = local.test_ou_controls
      }, ou, [])
    ))
  }
```

## Removing a control

To remove a control simply remove it from the `locals.tf` file. Do not delete it manually in the console otherwise it wil be enabled again when the pipeline next runs.

---

### Approvers
See the current list of approvers in the [Cyber AWS Control Approvers]{https://dev.azure.com/severntrent/aws-security/_settings/permissions}